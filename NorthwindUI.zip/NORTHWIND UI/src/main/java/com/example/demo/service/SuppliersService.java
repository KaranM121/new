package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.SuppliersNotFoundException;
import com.example.demo.model.Suppliers;

public interface SuppliersService {

	Suppliers getSuppliersById(int SuppliersNumber) throws SuppliersNotFoundException;

	List<Suppliers> getAllSuppliers();

	void createSuppliers(Suppliers Suppliers);

	Suppliers updateSuppliers(Suppliers Suppliers) throws SuppliersNotFoundException;

	void deleteSuppliers(int SuppliersNumber) throws SuppliersNotFoundException;

}