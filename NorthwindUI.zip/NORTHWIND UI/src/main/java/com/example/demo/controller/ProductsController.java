package com.example.demo.controller;
import java.util.List;
import java.util.Map;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.demo.model.Products;
import com.example.demo.service.ProductsService;
import com.example.demo.exception.ProductsNotFoundException;

 

@RestController
@RequestMapping("/api/products")
public class ProductsController {
	 @Autowired
	    private ProductsService productsService;

 

	    // POST endpoint to add a new Product object to the database
	    @PostMapping("/")
	    public ResponseEntity<String> addProduct(@RequestBody Products product) {
	        productsService.createProducts(product);
	        return ResponseEntity.status(HttpStatus.CREATED).body("Record Added Successfully!!");
	    } 

	    // Exception handler for ProductsNotFoundException
	    @ExceptionHandler(ProductsNotFoundException.class)
	    public ResponseEntity<String> handleProductsNotFoundException(ProductsNotFoundException ex) {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
	    }


	    @GetMapping("/")
	    public ResponseEntity<List<Products>> getAllProducts() {
	        List<Products> products = productsService.getAllProducts();
	        return ResponseEntity.ok(products);
	    }

 

	    // Endpoint to update the whole product information by ProductID using PUT
	    @PutMapping("/edit/{productId}")
	    public ResponseEntity<Void> updateProduct(@PathVariable int productId, @RequestBody Products product) {
	        try {
	            Products updatedProduct = productsService.updateProducts(product);
	            if (updatedProduct != null) {
	                return ResponseEntity.noContent().build();
	            } else {
	                return ResponseEntity.notFound().build();
	            }
	        } catch (ProductsNotFoundException e) {
	            return ResponseEntity.notFound().build();
	        }
	    }

 

	    // Endpoint to update the whole product information by ProductID using PATCH
	    @PatchMapping("/edit/{productId}")
	    public ResponseEntity<Void> partialUpdateProduct(@PathVariable int productId, @RequestBody Products product) {
	        try {
	            Products existingProduct = productsService.getProductsById(productId);
	            if (existingProduct != null) {
	                // Update specific fields of the product based on the PATCH request
	                if (product.getProductName() != null) {
	                    existingProduct.setProductName(product.getProductName());
	                }
	                if (product.getUnitPrice() != 0.0) {
	                    existingProduct.setUnitPrice(product.getUnitPrice());
	                }
	                // Add more fields as needed

 

	                productsService.updateProducts(existingProduct);
	                return ResponseEntity.noContent().build();
	            } else {
	                return ResponseEntity.notFound().build();
	            }
	        } catch (ProductsNotFoundException e) {
	            return ResponseEntity.notFound().build();
	        }

 

	    }

 

	    // Endpoint to search for products by QuantityPerUnit
	    @GetMapping("/quantityPerUnit/{quantityPerUnit}")
	    public ResponseEntity<List<Products>> searchQuantityPerUnit(@PathVariable int quantityPerUnit) {
	        List<Products> products = productsService.getQuantityPerUnit(quantityPerUnit);
	        return ResponseEntity.ok(products);
	    }

 

	    // Endpoint to display discontinued products
	    @GetMapping("/discontinued")
	    public ResponseEntity<List<Products>> getDiscontinuedProducts() {
	        List<Products> products = productsService.getDiscounted();
	        return ResponseEntity.ok(products);
	    }

 

	    // Endpoint to get products with UnitPrice less than a specified UnitPrice
	    @GetMapping("/unitPriceLessThan/{unitPrice}")
	    public ResponseEntity<List<Products>> getProductsByUnitPriceLessThan(@PathVariable double unitPrice) {
	        List<Products> products = productsService.getProductsByUnitPriceLessThan(unitPrice);
	        return ResponseEntity.ok(products);
	    }


	 // Endpoint to search products by CategoryName
	    @GetMapping("/ByCategoryName/{categoryName}")
	    public ResponseEntity<List<Products>> getProductsByCategoryName(@PathVariable String categoryName) {
	        List<Products> products = productsService.getProductsByCategoryName(categoryName);
	        return ResponseEntity.ok(products);
	    }

 

	    // Endpoint to display CompanyName, CategoryName, and ProductName
	    @GetMapping("/ProductDetails")
	    public ResponseEntity<List<Map<String, String>>> getProductDetails() {
	        List<Map<String, String>> productDetails = productsService.getProductDetails();
	        return ResponseEntity.ok(productDetails);
	    }

 

	    // Endpoint to display products whose UnitPrice is less than the average UnitPrice of a SupplierID
	    @GetMapping("/ProductDetails/SupplierID/{supplierId}")
	    public ResponseEntity<List<Products>> getProductsBySupplierIda(@PathVariable int supplierId) {
	        List<Products> products = productsService.getProductsBySupplierId(supplierId);
	        return ResponseEntity.ok(products);
	    }

 

	    // Endpoint to display CompanyName that supplies more than a given number of products
	    @GetMapping("/CompanyName")
	    public ResponseEntity<List<String>> getSuppliersByProductCount(@RequestParam int productCount) {
	        List<String> companyNames = productsService.getSuppliersByProductCount(productCount);
	        return ResponseEntity.ok(companyNames);
	    }

 

	    // Endpoint to search products by SupplierID
	    @GetMapping("/ProductBySupplier/{supplierId}")
	    public ResponseEntity<List<Products>> getProductsBySupplierId(@PathVariable int supplierId) {
	        List<Products> products = productsService.getProductsBySupplierId(supplierId);
	        return ResponseEntity.ok(products);
	    }

 

	    // Endpoint to update the UnitPrice of a product by ProductID using PUT
	    @PutMapping("/Edit/ProductID/{productId}")
	    public ResponseEntity<Void> updateUnitPrice(@PathVariable int productId, @RequestParam double unitPrice) {
	        try {
	            Products existingProduct = productsService.getProductsById(productId);
	            if (existingProduct != null) {
	                existingProduct.setUnitPrice(unitPrice);
	                productsService.updateProducts(existingProduct);
	                return ResponseEntity.noContent().build();
	            } else {
	                return ResponseEntity.notFound().build();
	            }
	        } catch (ProductsNotFoundException e) {
	            return ResponseEntity.notFound().build();
	        }
	    }

 

	    // Endpoint to search products by UnitInStock
	    @GetMapping("/UnitInStock/{unitInStock}")
	    public ResponseEntity<List<Products>> getProductsByUnitInStock(@PathVariable int unitInStock) {
	        List<Products> products = productsService.getProductsByUnitInStock(unitInStock);
	        return ResponseEntity.ok(products);
	    }

 

	    // Endpoint to display products with UnitsOnOrder > 0
	    @GetMapping("/UnitsOnOrder")
	    public ResponseEntity<List<Products>> getProductsUnitsOnOrderGreaterThanZero() {
	        List<Products> products = productsService.getProductsUnitsOnOrderGreaterThanZero();
	        return ResponseEntity.ok(products);
	    }

 

	    // Endpoint to show ProductName and UnitPrice of out-of-stock products
	    @GetMapping("/OutOfStock")
	    public ResponseEntity<List<Map<String, Object>>> getOutOfStockProducts() {
	        List<Map<String, Object>> outOfStockProducts = productsService.getOutOfStockProducts();
	        return ResponseEntity.ok(outOfStockProducts);
	    }

 

	    // Endpoint to search products with maximum UnitPrice
	    @GetMapping("/ProductByMaxPrice")
	    public ResponseEntity<Products> getProductWithMaxPrice() {
	        Products product = productsService.getProductWithMaxPrice();
	        return ResponseEntity.ok(product);
	    }

 

	    // Endpoint to search products with UnitPrice greater than any other product
	    @GetMapping("/ProductByUnitPrice")
	    public ResponseEntity<List<Products>> getProductsByUnitPriceGreaterThanOthers() {
	        List<Products> products = productsService.getProductsByUnitPriceGreaterThanOthers();
	        return ResponseEntity.ok(products);
	    }

 

	    


}