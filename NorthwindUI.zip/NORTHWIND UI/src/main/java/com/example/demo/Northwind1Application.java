package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.model.CustomerDemographics;
import com.example.demo.model.OrderDetails;
import com.example.demo.repository.CategoriesRepository;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.EmployeesRepository;
import com.example.demo.repository.OrderDetailsRepository;
import com.example.demo.repository.OrdersRepository;
import com.example.demo.repository.ProductsRepository;
import com.example.demo.repository.RegionRepository;
import com.example.demo.repository.ShippersRepository;
import com.example.demo.repository.SuppliersRepository;
import com.example.demo.repository.TerritoriesRepository;

@SpringBootApplication
public class Northwind1Application implements CommandLineRunner {

//	@Autowired
//	ProductsRepository prepo;
//	
//	@Autowired
//	CategoriesRepository crepo;
//	
//	@Autowired
//	CustomerDemographics cdrepo;
//	
//	@Autowired
//	CustomerRepository crrepo;
//	
//	@Autowired
//	EmployeesRepository errepo;
//	
//	
//	@Autowired
//	OrdersRepository orrepo;
//	
//	@Autowired
//	RegionRepository rrrepo;
//	
//	@Autowired
//	ShippersRepository srrepo;
//	
//	@Autowired
//	SuppliersRepository surrepo;
//	
//	@Autowired
//	TerritoriesRepository trrepo;
//	
//	@Autowired
//	OrderDetailsRepository odrepo;
//	
   
	
	
	public static void main(String[] args) {
		SpringApplication.run(Northwind1Application.class, args);
	}

	 @Override
	    public void run(String... args) throws Exception {
	       
	       
	       

}
	 
}

