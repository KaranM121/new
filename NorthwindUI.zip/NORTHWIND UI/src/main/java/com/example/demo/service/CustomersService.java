package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.CustomerNotFoundException;
import com.example.demo.model.Customers;

public interface CustomersService {

	

	List<Customers> getAllCustomers();

	void createCustomer(Customers Customer);

	Customers updateCustomer(Customers Customer) throws CustomerNotFoundException;

	void deleteCustomer(int CustomerNumber) throws CustomerNotFoundException;

	Customers getCustomerById(int CustomerNumber) throws CustomerNotFoundException;

	List<Customers> searchCustomersByCompanyName(String companyName);

	List<Customers> displayCustomersByContactTitle(String contactTitle);

	List<Customers> searchCustomersByCountry(String country);

	Customers assignAddressToCustomer(long customerId, Customers customer);

	List<Customers> searchCustomersByCity(String city);

	List<Customers> searchCustomersByRegion(String region);

	List<Customers> searchCustomersWithRegionNotNull();

	List<String> displayUniqueContactTitle();

	Customers updateContactName(long customerId, String contactName);

	Customers updateRegion(long customerId, String region);

	Customers searchCustomerByFax(String fax);

	List<Object[]> displayNumberOfCustomersByCountry();
	
	

}