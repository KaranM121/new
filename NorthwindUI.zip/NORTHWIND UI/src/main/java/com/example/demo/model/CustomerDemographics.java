package com.example.demo.model;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Service;


@Entity
@Table(name="CUSTOMER_DEMOGRAPHICS")
@Service
public class CustomerDemographics {
	
	    @Id
	    @Column(name="CUSTOMER_TYPE_ID")
	    private long customerTypeID;

	    @Column(name="CUSTOMER_DESC")
	    private String customerDesc;
	    
	    
	    @ManyToMany(mappedBy = "customerDemographics")
	    private Set<Customers> customers = new HashSet<>();


		public long getCustomerTypeID() {
			return customerTypeID;
		}


		public void setCustomerTypeID(long customerTypeID) {
			this.customerTypeID = customerTypeID;
		}


		public String getCustomerDesc() {
			return customerDesc;
		}


		public void setCustomerDesc(String customerDesc) {
			this.customerDesc = customerDesc;
		}


		public Set<Customers> getCustomers() {
			return customers;
		}


		public void setCustomers(Set<Customers> customers) {
			this.customers = customers;
		}
	    
	    
	    
	    
}
