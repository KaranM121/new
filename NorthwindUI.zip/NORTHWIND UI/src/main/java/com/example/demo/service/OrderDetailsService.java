package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.OrderDetailsNotFoundException;
import com.example.demo.model.OrderDetails;

public interface OrderDetailsService {

	OrderDetails getOrderDetailsById(int OrderDetailsNumber) throws OrderDetailsNotFoundException;

	List<OrderDetails> getAllOrderDetails();

	void createOrderDetails(OrderDetails OrderDetails);

	OrderDetails updateOrderDetails(OrderDetails OrderDetails) throws OrderDetailsNotFoundException;

	void deleteOrderDetails(int OrderDetailsNumber) throws OrderDetailsNotFoundException;

}