package com.example.demo.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employees;
import com.example.demo.dto.EmployeeAgeInfo;
import com.example.demo.dto.EmployeeTerritoryRegion;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.repository.EmployeesRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeesRepository employeeRepository;

	@Override
	public Employees getEmployeeById(int employeeNumber) throws EmployeeNotFoundException {
		
		if (employeeRepository.findById(employeeNumber).isEmpty())
			
			throw new EmployeeNotFoundException("the employee with" + employeeNumber + "does not exists");
		
		return employeeRepository.findById(employeeNumber).get();
	}

	@Override
	public List<Employees> getAllEmployees() {
		return employeeRepository.findAll();
	}

	@Override
	public void createEmployee(Employees employee) {
		employeeRepository.save(employee);

	}

	@Override
	public Employees updateEmployee(Employees employee) throws EmployeeNotFoundException {
		int employeeId = employee.getId();
		if (employeeRepository.findById(employeeId).isEmpty()) {
	        throw new EmployeeNotFoundException("The employee with ID " + employeeId + " does not exist");
	    }
	    return employeeRepository.save(employee);
	}

	@Override
	public void deleteEmployee(int employeeNumber) throws EmployeeNotFoundException {
		
		if (employeeRepository.findById(employeeNumber).isEmpty())
			
			throw new EmployeeNotFoundException("the employee with" + employeeNumber + "does not exists");
		employeeRepository.delete(employeeRepository.findById(employeeNumber).get());

	}

	 @Override
	    public List<Employees> getEmployeeByfirstName(String firstName) {
	        return employeeRepository.findByfirstName(firstName);
	    }

	@Override
	public List<Employees> getEmployeeByCity(String city) {
		
		return employeeRepository.findEmployeesByCity(city);
	}

	@Override
	public List<Employees> findByfirstName(String firstName) {
		
		return employeeRepository.findByfirstName(firstName);
	}

	
	@Override
	public List<Employees> getEmployeeByTitle(String title) {
	    return employeeRepository.getEmployeeByTitle(title);
	}

	
	  @Override public List<Employees> getEmployeeByAge(Date birthDate) {
	  
	  return employeeRepository.findEmployeesByBirthDate(birthDate); }
	 
	@Override
	public List<Employees> getEmployeeByBirthDate(Date birthDate) {
		
		return employeeRepository.findEmployeesByBirthDate(birthDate);
	}
	
	@Override
    public List<EmployeeAgeInfo> getEmployeeAgeInfoByBirthDate(Date birthDate) {
        return employeeRepository.findEmployeeAgeInfoByBirthDate(birthDate);
    }
	

	@Override
	public List<EmployeeAgeInfo> getEmployeeInfoByAge(Date birthDate) {

		return null;
	}

	@Override
	public Map<String, String> getManagerNamesForEachEmployee() {
		
		return null;
	}

	@Override
	public Map<String, Integer> getNumberOfEmployeesUnderEachManager() {
		
		return null;
	}

	@Override
	public List<EmployeeTerritoryRegion> getEmployeeTerritoriesRegion() {
		
		return null;
	}


	
	

	
	

}

