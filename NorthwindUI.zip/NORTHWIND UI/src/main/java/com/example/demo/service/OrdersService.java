package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.OrdersNotFoundException;
import com.example.demo.model.Orders;

public interface OrdersService {

	Orders getOrdersById(int OrdersNumber) throws OrdersNotFoundException;

	List<Orders> getAllOrderss();

	void createOrders(Orders Orders);

	Orders updateOrders(Orders Orders) throws OrdersNotFoundException;

	void deleteOrders(int OrdersNumber) throws OrdersNotFoundException;

}