package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Customers;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.exception.CustomerNotFoundException;

@Service
public class CustomersServiceImpl implements CustomersService {

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public Customers getCustomerById(int CustomerNumber) throws CustomerNotFoundException {
		
		if (customerRepository.findById(CustomerNumber).isEmpty())
			
			throw new CustomerNotFoundException("the Customer with" + CustomerNumber + "does not exists");
		
		return customerRepository.findById(CustomerNumber).get();
	}

	@Override
	public List<Customers> getAllCustomers() {
		return customerRepository.findAll();
	}

	@Override
	public void createCustomer(Customers customer) {
		customerRepository.save(customer);

	}

	@Override
	public Customers updateCustomer(Customers customer) throws CustomerNotFoundException {
	    long customerId = customer.getCustomerId(); // Use getCustomerId() to get the customer ID
	    if (customerRepository.findById((int) customerId).isEmpty()) {
	        throw new CustomerNotFoundException("The Customer with ID " + customerId + " does not exist");
	    }
	    return customerRepository.save(customer);
	}


	@Override
	public void deleteCustomer(int CustomerNumber) throws CustomerNotFoundException {
		
		if (customerRepository.findById(CustomerNumber).isEmpty())
			
			throw new CustomerNotFoundException("the Customer with" + CustomerNumber + "does not exists");
		customerRepository.delete(customerRepository.findById(CustomerNumber).get());

	}

	@Override
	public List<Customers> searchCustomersByCompanyName(String companyName) {
		
		return customerRepository.searchCustomersByCompanyName(companyName);
	}

	@Override
	public List<Customers> displayCustomersByContactTitle(String contactTitle) {
		
		return customerRepository.displayCustomersByContactTitle(contactTitle);
	}

	@Override
	public List<Customers> searchCustomersByCountry(String country) {
		// TODO Auto-generated method stub
		return customerRepository.searchCustomersByCountry(country);
	}

	@Override
	public Customers assignAddressToCustomer(long customerId, Customers customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customers> searchCustomersByCity(String city) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customers> searchCustomersByRegion(String region) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customers> searchCustomersWithRegionNotNull() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> displayUniqueContactTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customers updateContactName(long customerId, String contactName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customers updateRegion(long customerId, String region) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customers searchCustomerByFax(String fax) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object[]> displayNumberOfCustomersByCountry() {
		// TODO Auto-generated method stub
		return null;
	}




}

