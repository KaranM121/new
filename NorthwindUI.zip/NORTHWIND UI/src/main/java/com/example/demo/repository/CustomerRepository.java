package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.example.demo.model.Customers;

import java.util.List;

public interface CustomerRepository extends JpaRepository<Customers, Integer> {

    // JPQL query to search Customers by CompanyName
    @Query("SELECT c FROM Customers c WHERE c.companyName = :companyName")
    List<Customers> searchCustomersByCompanyName(@Param("companyName") String companyName);

    // JPQL query to display Customers by ContactTitle in Descending Order
    @Query("SELECT c FROM Customers c WHERE c.contactTitle = :contactTitle ORDER BY c.contactTitle DESC")
    List<Customers> displayCustomersByContactTitle(@Param("contactTitle") String contactTitle);

    // JPQL query to search Customers by Country
    @Query("SELECT c FROM Customers c WHERE c.country = :country")
    List<Customers> searchCustomersByCountry(@Param("country") String country);

    // JPQL query to search Customers by City
    @Query("SELECT c FROM Customers c WHERE c.city = :city")
    List<Customers> searchCustomersByCity(@Param("city") String city);

    // JPQL query to search Customers by Region
    @Query("SELECT c FROM Customers c WHERE c.region = :region")
    List<Customers> searchCustomersByRegion(@Param("region") String region);

    // JPQL query to search Customers whose Region does not contain null value
    @Query("SELECT c FROM Customers c WHERE c.region IS NOT NULL")
    List<Customers> searchCustomersWithRegionNotNull();

    // JPQL query to display the unique ContactTitle
    @Query("SELECT DISTINCT c.contactTitle FROM Customers c")
    List<String> displayUniqueContactTitle();

    // JPQL query to update the ContactName of a Customer
    @Query("UPDATE Customers c SET c.contactName = :contactName WHERE c.customerId = :customerId")
    int updateContactName(@Param("customerId") long customerId, @Param("contactName") String contactName);

    // JPQL query to update Region of a Customer
    @Query("UPDATE Customers c SET c.region = :region WHERE c.customerId = :customerId")
    int updateRegion(@Param("customerId") long customerId, @Param("region") String region);

    // JPQL query to search the Customer by Fax
    @Query("SELECT c FROM Customers c WHERE c.fax = :fax")
    Customers searchCustomerByFax(@Param("fax") String fax);

    // JPQL query to display the number of Customers from each Country
    @Query("SELECT c.country, COUNT(c) FROM Customers c GROUP BY c.country")
    List<Object[]> displayNumberOfCustomersByCountry();
}
