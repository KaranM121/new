package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.model.Customers;
import com.example.demo.service.CustomersService;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomersService customerService;

    // Endpoint to add a new Customer Object in DB
    @PostMapping("/")
    public String addCustomer(@RequestBody Customers customer) {
        customerService.createCustomer(customer);
        return "Record Created Successfully";
    }

    // Endpoint to get all Customers
    @GetMapping("/")
    public List<Customers> getAllCustomers() {
        return customerService.getAllCustomers();
    }

    // Endpoint to search Customers by CompanyName
    @GetMapping("/CompanyName/{companyName}")
    public List<Customers> searchCustomersByCompanyName(@PathVariable String companyName) {
        return customerService.searchCustomersByCompanyName(companyName);
    }

    // Endpoint to display Customers by ContactTitle in Descending Order
    @GetMapping("/ContactTitle/{contactTitle}")
    public List<Customers> displayCustomersByContactTitle(@PathVariable String contactTitle) {
        return customerService.displayCustomersByContactTitle(contactTitle);
    }

    // Endpoint to search Customers by Country
    @GetMapping("/Country/{country}")
    public List<Customers> searchCustomersByCountry(@PathVariable String country) {
        return customerService.searchCustomersByCountry(country);
    }

    // Endpoint to assign Address to a Customer
    @PutMapping("/Edit/{customerId}")
    public Customers assignAddressToCustomer(@PathVariable long customerId, @RequestBody Customers customer) {
        return customerService.assignAddressToCustomer(customerId, customer);
    }

    // Endpoint to search Customers by City
    @GetMapping("/City/{city}")
    public List<Customers> searchCustomersByCity(@PathVariable String city) {
        return customerService.searchCustomersByCity(city);
    }

    // Endpoint to search Customers by Region
    @GetMapping("/Region/{region}")
    public List<Customers> searchCustomersByRegion(@PathVariable String region) {
        return customerService.searchCustomersByRegion(region);
    }

    // Endpoint to search Customers whose Region does not contain null value
    @GetMapping("/RegionNotnull")
    public List<Customers> searchCustomersWithRegionNotNull() {
        return customerService.searchCustomersWithRegionNotNull();
    }

    // Endpoint to display the unique ContactTitle
    @GetMapping("/UniqueContactTitle")
    public List<String> displayUniqueContactTitle() {
        return customerService.displayUniqueContactTitle();
    }

    // Endpoint to update the ContactName of a Customer
    @PutMapping("/Edit/{customerId}/ContactName")
    public Customers updateContactName(@PathVariable long customerId, @RequestBody Customers customer) {
        return customerService.updateContactName(customerId, customer.getContactName());
    }

    // Endpoint to update Region of a Customer
    @PatchMapping("/Edit/{customerId}/Region")
    public Customers updateRegion(@PathVariable long customerId, @RequestBody Customers customer) {
        return customerService.updateRegion(customerId, customer.getRegion());
    }

    // Endpoint to search the Customer by Fax
    @GetMapping("/Fax/{fax}")
    public Customers searchCustomerByFax(@PathVariable String fax) {
        return customerService.searchCustomerByFax(fax);
    }

    // Endpoint to display the number of Customers from each Country
    @GetMapping("/NumberofCustomersByCountry")
    public List<Object[]> displayNumberOfCustomersByCountry() {
        return customerService.displayNumberOfCustomersByCountry();
    }
}
