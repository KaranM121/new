package com.example.demo.service;
import com.example.demo.exception.TerritoriesNotFoundException;
import com.example.demo.model.Territories;
import java.util.List;

public interface TerritoriesService {
	Territories getTerritoriesById(int territoriesNumber) throws TerritoriesNotFoundException;

	List<Territories> getAllTerritories();

	void createTerritories(Territories territories);

	Territories updateTerritories(Territories territories) throws TerritoriesNotFoundException;

	void deleteTerritories(int territoriesNumber) throws TerritoriesNotFoundException;
}
