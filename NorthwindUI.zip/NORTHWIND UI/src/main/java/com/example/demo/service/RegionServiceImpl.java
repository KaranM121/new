package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Region;
import com.example.demo.exception.RegionNotFoundException;
import com.example.demo.repository.RegionRepository;

@Service
public class RegionServiceImpl implements RegionService {

	@Autowired
	RegionRepository RegionRepository;

	@Override
	public Region getRegionById(int RegionNumber) throws RegionNotFoundException {
		
		if (RegionRepository.findById(RegionNumber).isEmpty())
			
			throw new RegionNotFoundException("the Region with" + RegionNumber + "does not exists");
		
		return RegionRepository.findById(RegionNumber).get();
	}

	@Override
	public List<Region> getAllRegions() {
		return RegionRepository.findAll();
	}

	@Override
	public void createRegion(Region region) {
		RegionRepository.save(region);

	}

	@Override
	public Region updateRegion(Region region) throws RegionNotFoundException {
	    Integer regionId = region.getRegionId();
	    if(RegionRepository.findById(regionId).isEmpty()) {
	    	
	        throw new RegionNotFoundException("The Region with ID " + regionId + " does not exist");
	    }
	    return RegionRepository.save(region);
	}


	@Override
	public void deleteRegion(int RegionNumber) throws RegionNotFoundException {
		
		if (RegionRepository.findById(RegionNumber).isEmpty())
			
			throw new RegionNotFoundException("the Region with" + RegionNumber + "does not exists");
		RegionRepository.delete(RegionRepository.findById(RegionNumber).get());

	}

}

