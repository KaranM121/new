package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Shippers;

import com.example.demo.exception.ShippersNotFoundException;

import com.example.demo.service.ShippersService;

@RestController

@RequestMapping("/api/shippers")
public class ShippersController {

	@Autowired
	private ShippersService shippersService;

	// Endpoint to add a new shipper
	@PostMapping("/add")
	public ResponseEntity<String> addShipper(@RequestBody Shippers shipper) {
		shippersService.createShipper(shipper);
		return new ResponseEntity<>("Record Added Successfully!!", HttpStatus.OK);
	}

	// Endpoint to get all shippers
	@GetMapping("/getAll")
	public ResponseEntity<Iterable<Shippers>> getAllShippers() {
		Iterable<Shippers> shippers = shippersService.getAllShippers();
		return new ResponseEntity<>(shippers, HttpStatus.OK);
	}

	
	// Endpoint to update shipper details by ID
	@PutMapping("/edit/{id}")
	public ResponseEntity<Shippers> updateShipperDetails1(@PathVariable int id, @RequestBody Shippers shipper) throws ShippersNotFoundException {
		shipper.setShipperID(id); // Set the shipper ID
		Shippers updatedShipper = shippersService.updateShipper(shipper);
		return new ResponseEntity<>(updatedShipper, HttpStatus.OK);

	}
	
	@GetMapping("/edit/{id}")
	public ResponseEntity<Shippers> updateShipperDetails(@PathVariable int id, @RequestBody Shippers shipper) throws ShippersNotFoundException {
		shipper.getShipperID(); // get the shipper ID
		Shippers updatedShipper = shippersService.updateShipper(shipper);
		return new ResponseEntity<>(updatedShipper, HttpStatus.OK);

	}
	
	
	@DeleteMapping("/del/{countryId}")
    public ResponseEntity<Void> deleteShipper(@PathVariable("countryId") int countryId) throws ShippersNotFoundException {
		shippersService.deleteShipper(countryId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

	
	@GetMapping("/{companyName}")
	public ResponseEntity<List<Shippers>> searchShipperByCompanyName(@PathVariable String companyName) throws ShippersNotFoundException {
		List<Shippers> shippers = shippersService.getShippersByCompanyName(companyName);
		if (shippers.isEmpty()) {
			throw new ShippersNotFoundException("No Shippers found with CompanyName: " + companyName);
		}
		return new ResponseEntity<>(shippers, HttpStatus.OK);
	}

    // Endpoint to edit specific Shipper details by ID using PATCH
	@PatchMapping("/edit/{id}") 
	public ResponseEntity<Void> editShipperDetails(@PathVariable int id,@RequestBody Shippers updatedShipper) throws ShippersNotFoundException {
		Shippers existingShipper = shippersService.getShipperById(id);
		// Check if the shipper exists
		if (existingShipper != null) {
			// Update only the provided fields (e.g., companyName and phone)

			if (updatedShipper.getCompanyName() != null) {
				existingShipper.setCompanyName(updatedShipper.getCompanyName());
			}
			if (updatedShipper.getPhone() != null) {
				existingShipper.setPhone(updatedShipper.getPhone());
			}
			// Save the updated Shipper
			shippersService.updateShipper(existingShipper);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT); // 204 No Content
		} else {
			// Shipper not found
			throw new ShippersNotFoundException("Shipper with ID " + id + " not found");
		}
	}
}