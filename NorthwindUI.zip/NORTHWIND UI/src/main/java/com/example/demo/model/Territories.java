package com.example.demo.model;

import javax.persistence.*;

import java.util.HashSet;

import java.util.Set;

@Entity
@Table(name = "Territories")
public class Territories {

	@Id
	@Column(name = "TerritoryID")
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private int territoryId;

	@Column(name = "TERRITORY_DESCRIPTION")
	private String territoryDescription;

	@ManyToMany(mappedBy = "territories", fetch = FetchType.LAZY)
	private Set<Employees> employees = new HashSet<>();

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "REGION_ID")
	private Region region;

	public int getTerritoryId() {

		return territoryId;

	}

	public void setTerritoryId(int territoryId) {

		territoryId = territoryId;

	}

	public String getTerritoryDescription() {

		return territoryDescription;

	}

	public void setTerritoryDescription(String territoryDescription) {

		territoryDescription = territoryDescription;

	}

	public Set<Employees> getEmployees() {

		return employees;

	}

	public void setEmployees(Set<Employees> employees) {

		this.employees = employees;

	}

	public Region getRegion() {

		return region;

	}

	public void setRegion(Region region) {

		this.region = region;

	}

}