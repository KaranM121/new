package com.example.demo.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Territories;
import com.example.demo.exception.TerritoriesNotFoundException;
import com.example.demo.repository.TerritoriesRepository;

@Service
public class TerritoriesServiceImpl implements TerritoriesService{
	@Autowired
	TerritoriesRepository territoriesRepository;

	@Override
	public Territories getTerritoriesById(int territoriesNumber) throws TerritoriesNotFoundException {
		
		if (territoriesRepository.findById(territoriesNumber).isEmpty())
			
			throw new TerritoriesNotFoundException("the products with" + territoriesNumber + "does not exists");
		
		return territoriesRepository.findById(territoriesNumber).get();
	}

	@Override
	public List<Territories> getAllTerritories() {
		return territoriesRepository.findAll();
	}

	@Override
	public void createTerritories(Territories territories) {
		territoriesRepository.save(territories);

	}

	@Override
	public Territories updateTerritories(Territories territories) throws TerritoriesNotFoundException {
		int territoriesId = territories.getTerritoryId();
		if (territoriesRepository.findById(territoriesId).isEmpty()) {
	        throw new TerritoriesNotFoundException("The territories with ID " + territoriesId + " does not exist");
	    }
	    return territoriesRepository.save(territories);
	}

	@Override
	public void deleteTerritories(int territoriesNumber) throws TerritoriesNotFoundException {
		
		if (territoriesRepository.findById(territoriesNumber).isEmpty())
			
			throw new TerritoriesNotFoundException("the territories with" + territoriesNumber + "does not exists");
		territoriesRepository.delete(territoriesRepository.findById(territoriesNumber).get());

	}
}


