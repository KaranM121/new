package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Suppliers;
import com.example.demo.exception.SuppliersNotFoundException;
import com.example.demo.repository.SuppliersRepository;

@Service
public class SuppliersServiceImpl implements SuppliersService {

	@Autowired
	SuppliersRepository SuppliersRepository;

	@Override
	public Suppliers getSuppliersById(int SuppliersNumber) throws SuppliersNotFoundException {
		
		if (SuppliersRepository.findById(SuppliersNumber).isEmpty())
			
			throw new SuppliersNotFoundException("the Suppliers with" + SuppliersNumber + "does not exists");
		
		return SuppliersRepository.findById(SuppliersNumber).get();
	}

	@Override
	public List<Suppliers> getAllSuppliers() {
		return SuppliersRepository.findAll();
	}

	@Override
	public void createSuppliers(Suppliers Suppliers) {
		SuppliersRepository.save(Suppliers);

	}

	@Override
	public Suppliers updateSuppliers(Suppliers Suppliers) throws SuppliersNotFoundException {
		int SuppliersId = Suppliers.getSupplierID();
		if (SuppliersRepository.findById(SuppliersId).isEmpty()) {
	        throw new SuppliersNotFoundException("The Suppliers with ID " + SuppliersId + " does not exist");
	    }
	    return SuppliersRepository.save(Suppliers);
	}

	@Override
	public void deleteSuppliers(int SuppliersNumber) throws SuppliersNotFoundException {
		
		if (SuppliersRepository.findById(SuppliersNumber).isEmpty())
			
			throw new SuppliersNotFoundException("the Suppliers with" + SuppliersNumber + "does not exists");
		SuppliersRepository.delete(SuppliersRepository.findById(SuppliersNumber).get());

	}

}

