package com.example.demo.service;

 

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

 

import com.example.demo.model.Shippers;

import com.example.demo.exception.ShippersNotFoundException;

import com.example.demo.repository.ShippersRepository;

 

@Service

public class ShippersServiceImpl implements ShippersService {

 

    @Autowired

    private ShippersRepository shippersRepository;

 

    @Override

    public Shippers getShipperById(int shipperId) throws ShippersNotFoundException {

        if (shippersRepository.findById(shipperId).isEmpty()) {

            throw new ShippersNotFoundException("The shipper with ID " + shipperId + " does not exist");

        }

        return shippersRepository.findById(shipperId).get();

    }
 
    @Override

    public List<Shippers> getAllShippers() {

        return shippersRepository.findAll();

    }

 

    @Override

    public void createShipper(Shippers shipper) {

        shippersRepository.save(shipper);

    }

 

    @Override

    public Shippers updateShipper(Shippers shipper) throws ShippersNotFoundException {

   

        if (shippersRepository.findById(shipper.getShipperID()).isEmpty()) {

            throw new ShippersNotFoundException("The shipper with ID " + shipper.getShipperID() + " does not exist");

        }

        return shippersRepository.save(shipper);

    }

 

    @Override

    public List<Shippers> getShippersByCompanyName(String companyName) throws ShippersNotFoundException {

        List<Shippers> shippers = shippersRepository.getShippersByCompanyName(companyName);

 

        if (shippers.isEmpty()) {

            throw new ShippersNotFoundException("No Shippers found with CompanyName: " + companyName);

        }

 

        return shippers;

    }



    @Override
    public void deleteShipper(int shipperId) throws ShippersNotFoundException {
        if (shippersRepository.findById(shipperId).isEmpty()) {
            throw new ShippersNotFoundException("The shipper with ID " + shipperId + " does not exist");
        }
        shippersRepository.deleteById(shipperId);
    }

}