package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.example.demo.exception.TerritoriesNotFoundException;
import com.example.demo.model.Territories;
import com.example.demo.service.TerritoriesService;

import java.util.List;

@Controller
@RequestMapping("/api/territory")
public class TerritoriesController {
    @Autowired
    private TerritoriesService territoriesService;

    // POST endpoint to add a new Territory
    @PostMapping("/add")
    public ResponseEntity<String> createTerritories(@RequestBody Territories territories) {
        territoriesService.createTerritories(territories);
        return new ResponseEntity<>("Record Created Successfully", HttpStatus.CREATED);
    }

    // GET endpoint to display all Territories
    @GetMapping("/getAll")
    public List<Territories> getAllTerritories() {
        return territoriesService.getAllTerritories();
    }

    // PUT endpoint to update a Territory by TerritoryId
    @PutMapping("/{territoryId}")
    public ResponseEntity<Void> updateTerritories(@PathVariable int territoryId, @RequestBody Territories updatedTerritories) {
        try {
            updatedTerritories.setTerritoryId(territoryId);
            territoriesService.updateTerritories(updatedTerritories);
            return ResponseEntity.noContent().build();
        } catch (TerritoriesNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // GET endpoint to search for a Territory by TerritoryId
    @GetMapping("/{territoryId}")
    public ResponseEntity<Territories> getTerritoriesById(@PathVariable int territoryId) {
        try {
            Territories territories = territoriesService.getTerritoriesById(territoryId);
            return ResponseEntity.ok(territories);
        } catch (TerritoriesNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE endpoint to delete a Territory by TerritoryId
    @DeleteMapping("/{territoryId}")
    public ResponseEntity<Void> deleteTerritories(@PathVariable int territoryId) {
        try {
            territoriesService.deleteTerritories(territoryId);
            return ResponseEntity.noContent().build();
        } catch (TerritoriesNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
