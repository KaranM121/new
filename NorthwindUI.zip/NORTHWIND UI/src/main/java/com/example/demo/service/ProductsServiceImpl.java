package com.example.demo.service;

import java.util.List;

import java.util.Map;

 

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

 

import com.example.demo.model.Products;

import com.example.demo.exception.ProductsNotFoundException;

import com.example.demo.repository.ProductsRepository;

 

@Service

public class ProductsServiceImpl implements ProductsService{

	@Autowired

	ProductsRepository productsRepository;

 

	@Override

	public Products getProductsById(int productsNumber) throws ProductsNotFoundException {


		if (productsRepository.findById(productsNumber).isEmpty())


			throw new ProductsNotFoundException("the products with" + productsNumber + "does not exists");


		return productsRepository.findById(productsNumber).get();

	}

 

	@Override

	public List<Products> getAllProducts() {

		return productsRepository.findAll();

	}

 

	@Override

	public void createProducts(Products products) {

		productsRepository.save(products);

 

	}

 

	@Override

	public Products updateProducts(Products products) throws ProductsNotFoundException {

		int productsId = products.getProductId();

		if (productsRepository.findById(productsId).isEmpty()) {

	        throw new ProductsNotFoundException("The products with ID " + productsId + " does not exist");

	    }

	    return productsRepository.save(products);

	}

 

	@Override

	public void deleteProducts(int productsNumber) throws ProductsNotFoundException {


		if (productsRepository.findById(productsNumber).isEmpty())


			throw new ProductsNotFoundException("the products with" + productsNumber + "does not exists");

		productsRepository.delete(productsRepository.findById(productsNumber).get());

 

	}

 

	@Override

	public List<Products> getDiscounted() {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<Products> getProductsByUnitPriceLessThan(double unitPrice) {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<Products> getQuantityPerUnit(int quantityPerUnit) {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<Products> getProductsByCategoryName(String categoryName) {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<Map<String, String>> getProductDetails() {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<String> getSuppliersByProductCount(int productCount) {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<Products> getProductsByUnitInStock(int unitInStock) {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<Products> getProductsUnitsOnOrderGreaterThanZero() {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<Map<String, Object>> getOutOfStockProducts() {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public Products getProductWithMaxPrice() {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<Products> getProductsByUnitPriceGreaterThanOthers() {

		// TODO Auto-generated method stub

		return null;

	}

 

	@Override

	public List<Products> getProductsBySupplierId(int supplierId) {

		// TODO Auto-generated method stub

		return null;

	}



}