package com.example.demo.model;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "PRODUCTS")
public class Products {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PRODUCTID")
	private int productId;

	@Column(name = "PRODUCT_NAME")
	private String ProductName;

	@Column(name = "QUANTITY_PER_UNIT")
	private int quantityPerUnit;

	@Column(name = "UNIT_PRICE")
	private double unitPrice;

	@Column(name = "UNIT_IN_STOCK")
	private int unitsInStock;

	@Column(name = "UNIT_IN_ORDER")
	private int unitsOnOrder;

	@Column(name = "REORDER_LEVEL")
	private int reorderLevel;

	@Column(name = "DISCOUNTED")
	private int discounted;

	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "CATEGORY_ID")
    private Categories categories;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "SUPPLIER_ID")
    private Suppliers suppliers;
	

	@OneToMany(mappedBy = "products", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<OrderDetails> orderDetails;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

	public int getQuantityPerUnit() {
		return quantityPerUnit;
	}

	public void setQuantityPerUnit(int quantityPerUnit) {
		this.quantityPerUnit = quantityPerUnit;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getUnitsInStock() {
		return unitsInStock;
	}

	public void setUnitsInStock(int unitsInStock) {
		this.unitsInStock = unitsInStock;
	}

	public int getUnitsOnOrder() {
		return unitsOnOrder;
	}

	public void setUnitsOnOrder(int unitsOnOrder) {
		this.unitsOnOrder = unitsOnOrder;
	}

	public int getReorderLevel() {
		return reorderLevel;
	}

	public void setReorderLevel(int reorderLevel) {
		this.reorderLevel = reorderLevel;
	}

	public int getDiscounted() {
		return discounted;
	}

	public void setDiscounted(int discounted) {
		this.discounted = discounted;
	}

	public Categories getCategories() {
		return categories;
	}

	public void setCategories(Categories categories) {
		this.categories = categories;
	}

}
